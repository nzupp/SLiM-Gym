# SLiM-Gym
Gymnasium wrapper for SLiM 4 simulator enabling reinforcement learning for population genetics
