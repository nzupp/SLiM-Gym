# -*- coding: utf-8 -*-
"""
@author: nzupp

Init file for testing SLiM_Gym
"""

